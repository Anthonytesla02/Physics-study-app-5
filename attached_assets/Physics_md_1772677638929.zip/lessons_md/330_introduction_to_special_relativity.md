# Introduction to Special Relativity

[Original URL](https://openstax.org/books/college-physics-2e/pages/28-introduction-to-special-relativity)

![A shark floats on a net in a containment unit with two people in wet suits nearby. A tracking device is attached to the dorsal fin of the shark.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/56ac4bb1e24cf81c6ddc603b7f390b4a382cf87d)

Figure 28.1 Special relativity has implications and applications ranging from space travel and our understanding of time to everyday technologies such as Global Positioning Systems. In order to be effective, GPS, whether it is a part of a mobile phone or a shark tracking system, must account for relativistic principles such as time dilation. (credit: UW News/Flickr)

## Chapter Outline

[28.1 Einstein’s Postulates](28-1-einsteins-postulates)

[28.2 Simultaneity And Time Dilation](28-2-simultaneity-and-time-dilation)

[28.3 Length Contraction](28-3-length-contraction)

[28.4 Relativistic Addition of Velocities](28-4-relativistic-addition-of-velocities)

[28.5 Relativistic Momentum](28-5-relativistic-momentum)

[28.6 Relativistic Energy](28-6-relativistic-energy)

## Introduction to Special Relativity

Have you ever looked up at the night sky and dreamed of traveling to other planets in faraway star systems? Would there be other life forms? What would other worlds look like? You might imagine that such an amazing trip would be possible if we could just travel fast enough, but you will read in this chapter why this is not true. In 1905 Albert Einstein developed the theory of special relativity. This theory explains the limit on an object’s speed and describes the consequences.

Relativity does not only apply to far-reaching and (as yet) unrealized activities like human interstellar travel. It affects everyday life in the form of communication, global trade, and even medicine. For example, Global Positioning Systems, which drive everything from airplane navigation to smart phone maps, rely on signals captured by multiple orbiting satellites and highly accurate measurements of time. Every signal passing between satellites, towers, and devices must be precisely measured and account for the relativistic effect of curved space and time dilation (discussed below). Variations in Earth’s landscape, its non-spherical shape, and the effects of gravity must also be considered in order to obtain accurate measurements. One of the most important contributors to these systems was Gladys West, a computer scientist and mathematician working at the Naval Proving Ground, where GPS and related technologies were advanced. West had previously developed altimeter models and managed the world’s first satellite-based ocean mapping project (Seastat). She then developed and programmed the algorithms capable of calculating positions and Earth’s shape to sufficient precisions to enable the existence of GPS. In these calculations, she accounted for the impacts of relativity and other complex principles related to it.

_Relativity_. The word _relativity_ might conjure an image of Einstein, but the idea did not begin with him. People have been exploring relativity for many centuries. Relativity is the study of how different observers measure the same event. Galileo and Newton developed the first correct version of classical relativity. Einstein developed the modern theory of relativity. Modern relativity is divided into two parts. _Special relativity_ deals with observers who are moving at constant velocity. _General relativity_ deals with observers who are undergoing acceleration. Einstein is famous because his theories of relativity made revolutionary predictions. Most importantly, his theories have been verified to great precision in a vast range of experiments, altering forever our concept of space and time.

![Black and white photograph of Albert Einstein.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/1e39e4a2d61c89d72765932008ebcb195fbe1dbe)

Figure 28.2 Many people think that Albert Einstein (1879–1955) was the greatest physicist of the 20th century. Not only did he develop modern relativity, thus revolutionizing our concept of the universe, he also made fundamental contributions to the foundations of quantum mechanics. (credit: The Library of Congress)

It is important to note that although classical mechanics, in general, and classical relativity, in particular, are limited, they are extremely good approximations for large, slow-moving objects. Otherwise, we could not use classical physics to launch satellites or build bridges. In the classical limit (objects larger than submicroscopic and moving slower than about 1% of the speed of light), relativistic mechanics becomes the same as classical mechanics. This fact will be noted at appropriate places throughout this chapter.