# 30.2 Discovery of the Parts of the Atom: Electrons and Nuclei

[Original URL](https://openstax.org/books/college-physics-2e/pages/30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei)

## 30.2 Discovery of the Parts of the Atom: Electrons and Nuclei

### Learning Objectives

By the end of this section, you will be able to:

*   Describe how electrons were discovered.
*   Explain the Millikan oil drop experiment.
*   Describe Rutherford’s gold foil experiment.
*   Describe Rutherford’s planetary model of the atom.

Just as atoms are a substructure of matter, electrons and nuclei are substructures of the atom. The experiments that were used to discover electrons and nuclei reveal some of the basic properties of atoms and can be readily understood using ideas such as electrostatic and magnetic force, already covered in previous chapters.

In previous discussions, we have noted that positive charge is associated with nuclei and negative charge with electrons. We have also covered many aspects of the electric and magnetic forces that affect charges. We will now explore the discovery of the electron and nucleus as substructures of the atom and examine their contributions to the properties of atoms.

### The Electron

Gas discharge tubes, such as that shown in [Figure 30.4](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#import-auto-id2991497), consist of an evacuated glass tube containing two metal electrodes and a rarefied gas. When a high voltage is applied to the electrodes, the gas glows. These tubes were the precursors to today’s neon lights. They were first studied seriously by Heinrich Geissler, a German inventor and glassblower, starting in the 1860s. The English scientist William Crookes, among others, continued to study what for some time were called Crookes tubes, wherein electrons are freed from atoms and molecules in the rarefied gas inside the tube and are accelerated from the cathode (negative) to the anode (positive) by the high potential. These “_cathode rays_” collide with the gas atoms and molecules and excite them, resulting in the emission of electromagnetic (EM) radiation that makes the electrons’ path visible as a ray that spreads and fades as it moves away from the cathode.

Gas discharge tubes today are most commonly called cathode-ray tubes, because the rays originate at the cathode. Crookes showed that the electrons carry momentum (they can make a small paddle wheel rotate). He also found that their normally straight path is bent by a magnet in the direction expected for a negative charge moving away from the cathode. These were the first direct indications of electrons and their charge.

![Image of a gas discharge tube consisting of a glass vacuum tube containing two metal electrodes and a low-pressure gas to create light.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/3e58a3f8b21cc7308a4e3d50ebacd93c7a12ff5f)

Figure 30.4 A gas discharge tube glows when a high voltage is applied to it. Electrons emitted from the cathode are accelerated toward the anode; they excite atoms and molecules in the gas, which glow in response. Once called Geissler tubes and later Crookes tubes, they are now known as cathode-ray tubes (CRTs) and are found in older TVs, computer screens, and x-ray machines. When a magnetic field is applied, the beam bends in the direction expected for negative charge. (credit: Paul Downey, Flickr)

The English physicist J. J. Thomson (1856–1940) improved and expanded the scope of experiments with gas discharge tubes. (See [Figure 30.5](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#import-auto-id1352064) and [Figure 30.6](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#fs-id2509061).) He verified the negative charge of the cathode rays with both magnetic and electric fields. Additionally, he collected the rays in a metal cup and found an excess of negative charge. Thomson was also able to measure the ratio of the charge of the electron to its mass, qeqe/me/me—an important step to finding the actual values of both qeqe and meme. [Figure 30.7](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#fs-id961353) shows a cathode-ray tube, which produces a narrow beam of electrons that passes through charging plates connected to a high-voltage power supply. An electric field EE is produced between the charging plates, and the cathode-ray tube is placed between the poles of a magnet so that the electric field EE is perpendicular to the magnetic field BB of the magnet. These fields, being perpendicular to each other, produce opposing forces on the electrons. As discussed for mass spectrometers in [More Applications of Magnetism](22-11-more-applications-of-magnetism), if the net force due to the fields vanishes, then the velocity of the charged particle is _v\=E/Bv\=E/B_. In this manner, Thomson determined the velocity of the electrons and then moved the beam up and down by adjusting the electric field.

![A black and white image of scientist J. J. Thomson wearing a coat and oval shaped spectacles.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/885682f2044571d6b6f1cca77c9063489aff8958)

Figure 30.5 J. J. Thomson (credit: www.firstworldwar.com, via Wikimedia Commons)

![A diagram of the glass apparatus that was used to discover the electron in J. J. Thompson’s experiment.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/2a6c292e90fbf20b5ee4ab9659adb2643c840ef2)

Figure 30.6 Diagram of Thomson’s CRT. (credit: Kurzon, Wikimedia Commons)

![Image of a cathode ray tube on x axis between two inverted L shaped north and south pole magnets on y axis, with z axis as a wire carrying high voltage supply to the charging plates inside the C R T. Zoomed image of the charging plate area inside the C R T showing the intersection of magnetic field between the poles in red lines towards south pole on the y axis along with an electron beam in green color line with velocity v toward right on the x axis.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/12a2f0b0c5371f2787ad0d3f72a8055c9ef37013)

Figure 30.7 This schematic shows the electron beam in a CRT passing through crossed electric and magnetic fields and causing phosphor to glow when striking the end of the tube.

To see how the amount of deflection is used to calculate qe/meqe/me, note that the deflection is proportional to the electric force on the electron:

F\=qeE.F\=qeE.

30.1

But the vertical deflection is also related to the electron’s mass, since the electron’s acceleration is

a \= F m e . a \= F m e .

30.2

The value of FF is not known, since qeqe was not yet known. Substituting the expression for electric force into the expression for acceleration yields

a \= F m e \= q e E m e . a \= F m e \= q e E m e .

30.3

Gathering terms, we have

q e m e \= a E . q e m e \= a E .

30.4

The deflection is analyzed to get aa, and EE is determined from the applied voltage and distance between the plates; thus, qemeqeme can be determined. With the velocity known, another measurement of qemeqeme can be obtained by bending the beam of electrons with the magnetic field. Since Fmag\=qevB\=meaFmag\=qevB\=mea, we have qe/me\=a/vBqe/me\=a/vB. Consistent results are obtained using magnetic deflection.

What is so important about qe/meqe/me, the ratio of the electron’s charge to its mass? The value obtained is

qeme\=−1.76×1011 C/kg (electron).qeme\=−1.76×1011 C/kg (electron).

30.5

This is a huge number, as Thomson realized, and it implies that the electron has a very small mass. It was known from electroplating that about 108 C/kg108 C/kg is needed to plate a material, a factor of about 1000 less than the charge per kilogram of electrons. Thomson went on to do the same experiment for positively charged hydrogen ions (now known to be bare protons) and found a charge per kilogram about 1000 times smaller than that for the electron, implying that the proton is about 1000 times more massive than the electron. Today, we know more precisely that

qpmp\=9.58×107 C/kg (proton),qpmp\=9.58×107 C/kg (proton),

30.6

where qpqp is the charge of the proton and mpmp is its mass. This ratio (to four significant figures) is 1836 times less charge per kilogram than for the electron. Since the charges of electrons and protons are equal in magnitude, this implies mp\=1836memp\=1836me .

Thomson performed a variety of experiments using differing gases in discharge tubes and employing other methods, such as the photoelectric effect, for freeing electrons from atoms. He always found the same properties for the electron, proving it to be an independent particle. For his work, the important pieces of which he began to publish in 1897, Thomson was awarded the 1906 Nobel Prize in Physics. In retrospect, it is difficult to appreciate how astonishing it was to find that the atom has a substructure. Thomson himself said, “It was only when I was convinced that the experiment left no escape from it that I published my belief in the existence of bodies smaller than atoms.”

Thomson attempted to measure the charge of individual electrons, but his method could determine its charge only to the order of magnitude expected.

Since Faraday’s experiments with electroplating in the 1830s, it had been known that about 100,000 C per mole was needed to plate singly ionized ions. Dividing this by the number of ions per mole (that is, by Avogadro’s number), which was approximately known, the charge per ion was calculated to be about 1.6×10−19 C1.6×10−19 C, close to the actual value.

An American physicist, Robert Millikan (1868–1953) (see [Figure 30.8](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#import-auto-id1379919)), decided to improve upon Thomson’s experiment for measuring qeqe and was eventually forced to try another approach, which is now a classic experiment performed by students. The Millikan oil drop experiment is shown in [Figure 30.9](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#fs-id2010482).

![Black and white image of physicist Robert Millikan wearing a jacket and a bow tie.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/243dfb0f820ee2ca81ed55b9533c0eb47497f003)

Figure 30.8 Robert Millikan (credit: Unknown Author, via Wikimedia Commons)

![Image of the apparatus used in the Millikan oil drop experiment, consisting of a parallel pair of horizontal metal plates with a pin hole opening in the top plate. The top plate has positive charge and the bottom plate has negative charge. Picture of a flashlight as a bright source of light and a beam of light passing in between the plates from left is shown. A telescope is shown at the front and an oil atomizer above the positive plate is also depicted. A zoomed image of metal plates describing the force acting on the oil droplet is also shown. Arrows pointing upwards are forces of electric field while arrows pointing downwards depict the force of gravity.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/cd792a74ba8441b63303c9bb4587e86f3bd490e6)

Figure 30.9 The Millikan oil drop experiment produced the first accurate direct measurement of the charge on electrons, one of the most fundamental constants in nature. Fine drops of oil become charged when sprayed. Their movement is observed between metal plates with a potential applied to oppose the gravitational force. The balance of gravitational and electric forces allows the calculation of the charge on a drop. The charge is found to be quantized in units of −1.6 × 10 −19 C −1.6 × 10 −19 C , thus determining directly the charge of the excess and missing electrons on the oil drops.

In the Millikan oil drop experiment, fine drops of oil are sprayed from an atomizer. Some of these are charged by the process and can then be suspended between metal plates by a voltage between the plates. In this situation, the weight of the drop is balanced by the electric force:

m drop g \= q e E m drop g \= q e E

30.7

The electric field is produced by the applied voltage, hence, E\=V/dE\=V/d, and VV is adjusted to just balance the drop’s weight. The drops can be seen as points of reflected light using a microscope, but they are too small to directly measure their size and mass. The mass of the drop is determined by observing how fast it falls when the voltage is turned off. Since air resistance is very significant for these submicroscopic drops, the more massive drops fall faster than the less massive, and sophisticated sedimentation calculations can reveal their mass. Oil is used rather than water, because it does not readily evaporate, and so mass is nearly constant. Once the mass of the drop is known, the charge of the electron is given by rearranging the previous equation:

q \= m drop g E \= m drop gd V , q \= m drop g E \= m drop gd V ,

30.8

where dd is the separation of the plates and VV is the voltage that holds the drop motionless. (The same drop can be observed for several hours to see that it really is motionless.) By 1913 Millikan had measured the charge of the electron _qeqe_ to an accuracy of 1%, and he improved this by a factor of 10 within a few years to a value of −1.60×10−19 C−1.60×10−19 C. He also observed that all charges were multiples of the basic electron charge and that sudden changes could occur in which electrons were added or removed from the drops. For this very fundamental direct measurement of qeqe and for his studies of the photoelectric effect, Millikan was awarded the 1923 Nobel Prize in Physics.

With the charge of the electron known and the charge-to-mass ratio known, the electron’s mass can be calculated. It is

m \= q e q e m e . m \= q e q e m e .

30.9

Substituting known values yields

m e \= − 1.60 × 10 − 19 C − 1 . 76 × 10 11 C/kg m e \= − 1.60 × 10 − 19 C − 1 . 76 × 10 11 C/kg

30.10

or

me\=9.11×10−31 kg (electron’s mass),me\=9.11×10−31 kg (electron’s mass),

30.11

where the round-off errors have been corrected. The mass of the electron has been verified in many subsequent experiments and is now known to an accuracy of better than one part in one million. It is an incredibly small mass and remains the smallest known mass of any particle that has mass. (Some particles, such as photons, are massless and cannot be brought to rest, but travel at the speed of light.) A similar calculation gives the masses of other particles, including the proton. To three digits, the mass of the proton is now known to be

mp\=1.67×10−27 kg (proton’s mass),mp\=1.67×10−27 kg (proton’s mass),

30.12

which is nearly identical to the mass of a hydrogen atom. What Thomson and Millikan had done was to prove the existence of one substructure of atoms, the electron, and further to show that it had only a tiny fraction of the mass of an atom. The nucleus of an atom contains most of its mass, and the nature of the nucleus was completely unanticipated.

Another important characteristic of quantum mechanics was also beginning to emerge. All electrons are identical to one another. The charge and mass of electrons are not average values; rather, they are unique values that all electrons have. This is true of other fundamental entities at the submicroscopic level. All protons are identical to one another, and so on.

### The Nucleus

Here, we examine the first direct evidence of the size and mass of the nucleus. In later chapters, we will examine many other aspects of nuclear physics, but the basic information on nuclear size and mass is so important to understanding the atom that we consider it here.

Nuclear radioactivity was discovered in 1896, and it was soon the subject of intense study by a number of the best scientists in the world. Among them was New Zealander Lord Ernest Rutherford, who made numerous fundamental discoveries and earned the title of “father of nuclear physics.” Born in Nelson, Rutherford did his postgraduate studies at the Cavendish Laboratories in England before taking up a position at McGill University in Canada where he did the work that earned him a Nobel Prize in Chemistry in 1908. In the area of atomic and nuclear physics, there is much overlap between chemistry and physics, with physics providing the fundamental enabling theories. He returned to England in later years and had six future Nobel Prize winners as students. Rutherford used nuclear radiation to directly examine the size and mass of the atomic nucleus. The experiment he devised is shown in [Figure 30.10](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#import-auto-id1995579). A radioactive source that emits alpha radiation was placed in a lead container with a hole in one side to produce a beam of alpha particles, which are a type of ionizing radiation ejected by the nuclei of a radioactive source. A thin gold foil was placed in the beam, and the scattering of the alpha particles was observed by the glow they caused when they struck a phosphor screen.

![Image of Rutherford’s experiment depicting a cuboid shaped lead block having a radioactive sample in red colored circle, emitting a beam of alpha rays. The beam strikes a rectangular gold foil which lies inside a circular strip acting as a detecting screen. Two rays are reflected from the foil while the rest pass through the foil and hit the strip. The other part of the image shows magnified structure of gold foil with gold atoms with their nuclei. Diameter of gold atom is given as 10^{-10}m and the diameter of the nucleus of the atom is 10^{-15}m. Alpha rays in the form of arrows are shown passing horizontally through the atoms; some are shown deflected as they collide with the nuclei while the rest simply pass through.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/d9506db06b0b13d39e15c929598856b9b12f9865)

Figure 30.10 Rutherford’s experiment gave direct evidence for the size and mass of the nucleus by scattering alpha particles from a thin gold foil. Alpha particles with energies of about 5 MeV5 MeV are emitted from a radioactive source (which is a small metal container in which a specific amount of a radioactive material is sealed), are collimated into a beam, and fall upon the foil. The number of particles that penetrate the foil or scatter to various angles indicates that gold nuclei are very small and contain nearly all of the gold atom’s mass. This is particularly indicated by the alpha particles that scatter to very large angles, much like a soccer ball bouncing off a goalie’s head.

Alpha particles were known to be the doubly charged positive nuclei of helium atoms that had kinetic energies on the order of 5 MeV5 MeV when emitted in nuclear decay, which is the disintegration of the nucleus of an unstable nuclide by the spontaneous emission of charged particles. These particles interact with matter mostly via the Coulomb force, and the manner in which they scatter from nuclei can reveal nuclear size and mass. This is analogous to observing how a bowling ball is scattered by an object you cannot see directly. Because the alpha particle’s energy is so large compared with the typical energies associated with atoms (MeVMeV versus eVeV), you would expect the alpha particles to simply crash through a thin foil much like a supersonic bowling ball would crash through a few dozen rows of bowling pins. Thomson had envisioned the atom to be a small sphere in which equal amounts of positive and negative charge were distributed evenly. The incident massive alpha particles would suffer only small deflections in such a model. Instead, Rutherford and his collaborators found that alpha particles occasionally were scattered to large angles, some even back in the direction from which they came! Detailed analysis using conservation of momentum and energy—particularly of the small number that came straight back—implied that gold nuclei are very small compared with the size of a gold atom, contain almost all of the atom’s mass, and are tightly bound. Since the gold nucleus is several times more massive than the alpha particle, a head-on collision would scatter the alpha particle straight back toward the source. In addition, the smaller the nucleus, the fewer alpha particles that would hit one head on.

Although the results of the experiment were published by his colleagues in 1909, it took Rutherford two years to convince himself of their meaning. Like Thomson before him, Rutherford was reluctant to accept such radical results. Nature on a small scale is so unlike our classical world that even those at the forefront of discovery are sometimes surprised. Rutherford later wrote: “It was almost as incredible as if you fired a 15-inch shell at a piece of tissue paper and it came back and hit you. On consideration, I realized that this scattering backwards ... \[meant\] ... the greatest part of the mass of the atom was concentrated in a tiny nucleus.” In 1911, Rutherford published his analysis together with a proposed model of the atom. The size of the nucleus was determined to be about 10−15 m10−15 m, or 100,000 times smaller than the atom. This implies a huge density, on the order of 1015 g/cm31015 g/cm3, vastly unlike any macroscopic matter. Also implied is the existence of previously unknown nuclear forces to counteract the huge repulsive Coulomb forces among the positive charges in the nucleus. Huge forces would also be consistent with the large energies emitted in nuclear radiation.

The small size of the nucleus also implies that the atom is mostly empty inside. In fact, in Rutherford’s experiment, most alphas went straight through the gold foil with very little scattering, since electrons have such small masses and since the atom was mostly empty with nothing for the alpha to hit. There were already hints of this at the time Rutherford performed his experiments, since energetic electrons had been observed to penetrate thin foils more easily than expected. [Figure 30.11](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#import-auto-id1828262) shows a schematic of the atoms in a thin foil with circles representing the size of the atoms (about 10−10 m10−10 m) and dots representing the nuclei. (The dots are not to scale—if they were, you would need a microscope to see them.) Most alpha particles miss the small nuclei and are only slightly scattered by electrons. Occasionally, (about once in 8000 times in Rutherford’s experiment), an alpha hits a nucleus head-on and is scattered straight backward.

![The image shows an enlarged view of atoms in gold foil having a diameter of ten to the power minus ten meter and a dot within it representing the nucleus. A few alpha rays are shown passing through the atoms. Some are scattered as they hit the nuclei while some are just passing through.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/7d47e1681d1f68f27f8b7c15b33b496ca93af6d4)

Figure 30.11 An expanded view of the atoms in the gold foil in Rutherford’s experiment. Circles represent the atoms (about 10−10 m10−10 m in diameter), while the dots represent the nuclei (about 10−15 m10−15 m in diameter). To be visible, the dots are much larger than scale. Most alpha particles crash through but are relatively unaffected because of their high energy and the electron’s small mass. Some, however, head straight toward a nucleus and are scattered straight back. A detailed analysis gives the size and mass of the nucleus.

Based on the size and mass of the nucleus revealed by his experiment, as well as the mass of electrons, Rutherford proposed the planetary model of the atom. The planetary model of the atom pictures low-mass electrons orbiting a large-mass nucleus. The sizes of the electron orbits are large compared with the size of the nucleus, with mostly vacuum inside the atom. This picture is analogous to how low-mass planets in our solar system orbit the large-mass Sun at distances large compared with the size of the sun. In the atom, the attractive Coulomb force is analogous to gravitation in the planetary system. (See [Figure 30.12](30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei#import-auto-id1934843).) Note that a model or mental picture is needed to explain experimental results, since the atom is too small to be directly observed with visible light.

![The image shows three elliptical orbits showing electrons’ movement around a positive nucleus. The movement of the electrons in the orbit shown with arrows are opposite to each other.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/59d9587096d8db2892e7efd778c0392b09d3d599)

Figure 30.12 Rutherford’s planetary model of the atom incorporates the characteristics of the nucleus, electrons, and the size of the atom. This model was the first to recognize the structure of atoms, in which low-mass electrons orbit a very small, massive nucleus in orbits much larger than the nucleus. The atom is mostly empty and is analogous to our planetary system.

Rutherford’s planetary model of the atom was crucial to understanding the characteristics of atoms, and their interactions and energies, as we shall see in the next few sections. Also, it was an indication of how different nature is from the familiar classical world on the small, quantum mechanical scale. The discovery of a substructure to all matter in the form of atoms and molecules was now being taken a step further to reveal a substructure of atoms that was simpler than the 92 elements then known. We have continued to search for deeper substructures, such as those inside the nucleus, with some success. In later chapters, we will follow this quest in the discussion of quarks and other elementary particles, and we will look at the direction the search seems now to be heading.

#### Rutherford Scattering

How did Rutherford figure out the structure of the atom without being able to see it? Simulate the famous experiment in which he disproved the Plum Pudding model of the atom by observing alpha particles bouncing off atoms and determining that they must have a small core.

[Access multimedia content](http://openstax.org/books/college-physics-2e/pages/30-2-discovery-of-the-parts-of-the-atom-electrons-and-nuclei)