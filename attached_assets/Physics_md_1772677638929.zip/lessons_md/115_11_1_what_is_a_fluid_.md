# 11.1 What Is a Fluid?

[Original URL](https://openstax.org/books/college-physics-2e/pages/11-1-what-is-a-fluid)

## 11.1 What Is a Fluid?

### Learning Objectives

By the end of this section, you will be able to:

*   State the common phases of matter.
*   Explain the physical characteristics of solids, liquids, and gases.
*   Describe the arrangement of atoms in solids, liquids, and gases.

Matter most commonly exists as a solid, liquid, gas, or plasma; these states are known as the common _phases of matter_. Solids have a definite shape and a specific volume, liquids have a definite volume but their shape changes depending on the container in which they are held, gases have neither a definite shape nor a specific volume as their molecules move to fill the container in which they are held, and plasmas also have neither definite shape nor volume. (See [Figure 11.2](11-1-what-is-a-fluid#import-auto-id2402081).) Liquids, gases, and plasmas are considered to be fluids because they yield to shearing forces, whereas solids resist them. Note that the extent to which fluids yield to shearing forces (and hence flow easily and quickly) depends on a quantity called the viscosity which is discussed in detail in [Viscosity and Laminar Flow; Poiseuille’s Law](12-4-viscosity-and-laminar-flow-poiseuilles-law). We can understand the phases of matter and what constitutes a fluid by considering the forces between atoms that make up matter in the three phases.

![This figure has three parts. Part a shows a solid, and the atoms in the solid are shown as small red spheres held together in a grid. Part b shows a liquid in a short cylindrical container, and the atoms in the liquid are represented by small red spheres that can move past one another. The movement of the atoms is represented by arrows. Part c shows a cylinder that is labeled to indicate that it contains oxygen gas. The atoms in the gas are represented by small red spheres that move around. Their motion is indicated by arrows./](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/325ae488fd357d1dda90b8246773cbf238923932)

Figure 11.2 (a) Atoms in a solid always have the same neighbors, held near home by forces represented here by springs. These atoms are essentially in contact with one another. A rock is an example of a solid. This rock retains its shape because of the forces holding its atoms together. (b) Atoms in a liquid are also in close contact but can slide over one another. Forces between them strongly resist attempts to push them closer together and also hold them in close contact. Water is an example of a liquid. Water can flow, but it also remains in an open container because of the forces between its atoms. (c) Atoms in a gas are separated by distances that are considerably larger than the size of the atoms themselves, and they move about freely. A gas must be held in a closed container to prevent it from moving out freely. (d) A plasma is composed of electrons, protons, and ions that, like gases, are spaced far apart and move about freely.

Atoms in _solids_ are in close contact, with forces between them that allow the atoms to vibrate but not to change positions with neighboring atoms. (These forces can be thought of as springs that can be stretched or compressed, but not easily broken.) Thus a solid _resists_ all types of stress. A solid cannot be easily deformed because the atoms that make up the solid are not able to move about freely. Solids also resist compression, because their atoms form part of a lattice structure in which the atoms are a relatively fixed distance apart. Under compression, the atoms would be forced into one another. Most of the examples we have studied so far have involved solid objects which deform very little when stressed.

Atomic and molecular characteristics explain and underlie the macroscopic characteristics of solids and fluids. This submicroscopic explanation is one theme of this text and is highlighted in the Things Great and Small features in [Conservation of Momentum](8-3-conservation-of-momentum). See, for example, microscopic description of collisions and momentum or microscopic description of pressure in a gas. This present section is devoted entirely to the submicroscopic explanation of solids and liquids.

In contrast, _liquids_ deform easily when stressed and do not spring back to their original shape once the force is removed because the atoms are free to slide about and change neighbors—that is, they _flow_ (so they are a type of fluid), with the molecules held together by their mutual attraction. When a liquid is placed in a container with no lid on, it remains in the container (providing the container has no holes below the surface of the liquid!). Because the atoms are closely packed, liquids, like solids, resist compression.

Atoms in _gases_ and charged particles in _plasmas_ are separated by distances that are large compared with the size of the particles. The forces between the particles are therefore very weak, except when they collide with one another. Gases and plasmas thus not only flow (and are therefore considered to be fluids) but they are relatively easy to compress because there is much space and little force between the particles. When placed in an open container gases, unlike liquids, will escape. The major distinction is that gases are easily compressed, whereas liquids are not. Plasmas are difficult to contain because they have so much energy. When discussing how substances flow, we shall generally refer to both gases and liquids simply as fluids, and make a distinction between them only when they behave differently.

#### States of Matter—Basics

Heat, cool, and compress atoms and molecules and watch as they change between solid, liquid, and gas phases.

[Access multimedia content](http://openstax.org/books/college-physics-2e/pages/11-1-what-is-a-fluid)