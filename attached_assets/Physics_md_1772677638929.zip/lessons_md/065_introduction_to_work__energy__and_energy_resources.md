# Introduction to Work, Energy, and Energy Resources

[Original URL](https://openstax.org/books/college-physics-2e/pages/7-introduction-to-work-energy-and-energy-resources)

![A field with four wind turbines and the Sun setting in the background.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/3ee3b931e55f082fe8122a3a50d0f80ac150c847)

Figure 7.1 How many forms of energy can you identify in this photograph of a wind farm in Iowa? (credit: Jürgen from Sandesneben, Germany, Wikimedia Commons)

## Chapter Outline

[7.1 Work: The Scientific Definition](7-1-work-the-scientific-definition)

[7.2 Kinetic Energy and the Work-Energy Theorem](7-2-kinetic-energy-and-the-work-energy-theorem)

[7.3 Gravitational Potential Energy](7-3-gravitational-potential-energy)

[7.4 Conservative Forces and Potential Energy](7-4-conservative-forces-and-potential-energy)

[7.5 Nonconservative Forces](7-5-nonconservative-forces)

[7.6 Conservation of Energy](7-6-conservation-of-energy)

[7.7 Power](7-7-power)

[7.8 Work, Energy, and Power in Humans](7-8-work-energy-and-power-in-humans)

[7.9 World Energy Use](7-9-world-energy-use)

## Introduction to Work, Energy, and Energy Resources

_Energy_ plays an essential role both in everyday events and in scientific phenomena. You can no doubt name many forms of energy, from that provided by our foods, to the energy we use to run our cars, to the sunlight that warms us on the beach. You can also cite examples of what people call energy that may not be scientific, such as someone having an energetic personality. Not only does energy have many interesting forms, it is involved in almost all phenomena, and is one of the most important concepts of physics. What makes it even more important is that the total amount of energy in the universe is constant. Energy can change forms, but it cannot appear from nothing or disappear without a trace. Energy is thus one of a handful of physical quantities that we say is _conserved_.

Conservation of energy (as physicists like to call the principle that energy can neither be created nor destroyed) is based on experiment. For example, scientists Willem ’s Gravesande and Émilie du Châtelet undertook (separate) experiments where they dropped heavy lead balls into beds of clay. Du Châtelet showed that the balls that hit the clay with twice the velocity penetrated four times as deep into the clay; those with three times the velocity reached a depth nine times greater. This led her to develop a more accurate concept of energy conservation, expressed as E\=12mv2E\=12mv2. Even as scientists discovered new forms of energy, conservation of energy has always been found to apply. Perhaps the most dramatic example of this was supplied by Einstein when he suggested that mass is equivalent to energy (his famous equation E\=mc2E\=mc2).

From a societal viewpoint, energy is one of the major building blocks of modern civilization. Energy resources are key limiting factors to economic growth. The world use of energy resources, especially oil, continues to grow, with ominous consequences economically, socially, politically, and environmentally. We will briefly examine the world’s energy use patterns at the end of this chapter.

There is no simple, yet accurate, scientific definition for energy. Energy is characterized by its many forms and the fact that it is conserved. We can loosely define energy as the ability to do work, admitting that in some circumstances not all energy is available to do work. Because of the association of energy with work, we begin the chapter with a discussion of work. Work is intimately related to energy and how energy moves from one system to another or changes form.

[Access multimedia content](http://openstax.org/books/college-physics-2e/pages/7-introduction-to-work-energy-and-energy-resources)