# Introduction to Geometric Optics

[Original URL](https://openstax.org/books/college-physics-2e/pages/25-introduction-to-geometric-optics)

![People in white clothing covered from head to toe and wearing blue colored gloves are working in a research laboratory setting, one person holding a flash light and analyzing and another reading a manuscript and so on. Their images are seen on a smooth colored glass top of a work table.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/7523edbf6606aec344c56f23751269239993e68c)

Figure 25.1 Image seen as a result of reflection of light on a plane smooth surface. (credit: NASA Goddard Photo and Video, via Flickr)

## Chapter Outline

[25.1 The Ray Aspect of Light](25-1-the-ray-aspect-of-light)

[25.2 The Law of Reflection](25-2-the-law-of-reflection)

[25.3 The Law of Refraction](25-3-the-law-of-refraction)

[25.4 Total Internal Reflection](25-4-total-internal-reflection)

[25.5 Dispersion: The Rainbow and Prisms](25-5-dispersion-the-rainbow-and-prisms)

[25.6 Image Formation by Lenses](25-6-image-formation-by-lenses)

[25.7 Image Formation by Mirrors](25-7-image-formation-by-mirrors)

## Introduction to Geometric Optics

Geometric OpticsLight from this page or screen is formed into an image by the lens of your eye, much as the lens of the camera that made this photograph. Mirrors, like lenses, can also form images that in turn are captured by your eye.

Our lives are filled with light. Through vision, the most valued of our senses, light can evoke spiritual emotions, such as when we view a magnificent sunset or glimpse a rainbow breaking through the clouds. Light can also simply amuse us in a theater, or warn us to stop at an intersection. It has innumerable uses beyond vision. Light can carry telephone signals through glass fibers or cook a meal in a solar oven. Life itself could not exist without light’s energy. From photosynthesis in plants to the sun warming a cold-blooded animal, its supply of energy is vital.

![](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/e81c6be3cb4c19c06bf88922f0261b4420a6f6cb)

Figure 25.2 Double Rainbow over the bay of Pocitos in Montevideo, Uruguay. (credit: Madrax, Wikimedia Commons)

We already know that visible light is the type of electromagnetic waves to which our eyes respond. That knowledge still leaves many questions regarding the nature of light and vision. What is color, and how do our eyes detect it? Why do diamonds sparkle? How does light travel? How do lenses and mirrors form images? These are but a few of the questions that are answered by the study of optics. Optics is the branch of physics that deals with the behavior of visible light and other electromagnetic waves. In particular, optics is concerned with the generation and propagation of light and its interaction with matter. What we have already learned about the generation of light in our study of heat transfer by radiation will be expanded upon in later topics, especially those on atomic physics. Now, we will concentrate on the propagation of light and its interaction with matter.

It is convenient to divide optics into two major parts based on the size of objects that light encounters. When light interacts with an object that is several times as large as the light’s wavelength, its observable behavior is like that of a ray; it does not prominently display its wave characteristics. We call this part of optics “geometric optics.” This chapter will concentrate on such situations. When light interacts with smaller objects, it has very prominent wave characteristics, such as constructive and destructive interference. [Wave Optics](27-1-the-wave-aspect-of-light-interference) will concentrate on such situations.