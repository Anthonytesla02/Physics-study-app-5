# Introduction to Quantum Physics

[Original URL](https://openstax.org/books/college-physics-2e/pages/29-introduction-to-quantum-physics)

![A magnified image of a black fly obtained from an electron microscope showing its antennae and tentacles.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/17cee78bac176d01535f99d9bd6b68076e995afc)

Figure 29.1 A black fly imaged by an electron microscope is as monstrous as any science-fiction creature. (credit: U.S. Department of Agriculture via Wikimedia Commons)

## Chapter Outline

[29.1 Quantization of Energy](29-1-quantization-of-energy)

[29.2 The Photoelectric Effect](29-2-the-photoelectric-effect)

[29.3 Photon Energies and the Electromagnetic Spectrum](29-3-photon-energies-and-the-electromagnetic-spectrum)

[29.4 Photon Momentum](29-4-photon-momentum)

[29.5 The Particle-Wave Duality](29-5-the-particle-wave-duality)

[29.6 The Wave Nature of Matter](29-6-the-wave-nature-of-matter)

[29.7 Probability: The Heisenberg Uncertainty Principle](29-7-probability-the-heisenberg-uncertainty-principle)

[29.8 The Particle-Wave Duality Reviewed](29-8-the-particle-wave-duality-reviewed)

## Introduction to Quantum Physics

Quantum mechanics is the branch of physics needed to deal with submicroscopic objects. Because these objects are smaller than we can observe directly with our senses and generally must be observed with the aid of instruments, parts of quantum mechanics seem as foreign and bizarre as parts of relativity. But, like relativity, quantum mechanics has been shown to be valid—truth is often stranger than fiction.

Certain aspects of quantum mechanics are familiar to us. We accept as fact that matter is composed of atoms, the smallest unit of an element, and that these atoms combine to form molecules, the smallest unit of a compound. (See [Figure 29.2](29-introduction-to-quantum-physics#import-auto-id2057817).) While we cannot see the individual water molecules in a stream, for example, we are aware that this is because molecules are so small and so numerous in that stream. When introducing atoms, we commonly say that electrons orbit atoms in discrete shells around a tiny nucleus, itself composed of smaller particles called protons and neutrons. We are also aware that electric charge comes in tiny units carried almost entirely by electrons and protons. As with water molecules in a stream, we do not notice individual charges in the current through a lightbulb, because the charges are so small and so numerous in the macroscopic situations we sense directly.

![A model of an atom is shown. Atom is shown as a clump of small spherical balls at the center, representing the nucleus, surrounded by spherical and dumbbell-shaped electron clouds. A magnified view of the nucleus is shown as a bunch of small spherical balls.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/46b186aceadf66d068447fcb8806fef3417981ef)

Figure 29.2 Atoms and their substructure are familiar examples of objects that require quantum mechanics to be fully explained. Certain of their characteristics, such as the discrete electron shells, are classical physics explanations. In quantum mechanics we conceptualize discrete “electron clouds” around the nucleus.

Classical physics is a good approximation of modern physics under conditions first discussed in the [The Nature of Science and Physics](1-introduction-to-science-and-the-realm-of-physics-physical-quantities-and-units). Quantum mechanics is valid in general, and it must be used rather than classical physics to describe small objects, such as atoms.

Atoms, molecules, and fundamental electron and proton charges are all examples of physical entities that are quantized—that is, they appear only in certain discrete values and do not have every conceivable value. Quantized is the opposite of continuous. We cannot have a fraction of an atom, or part of an electron’s charge, or 14-1/3 cents, for example. Rather, everything is built of integral multiples of these substructures. Quantum physics is the branch of physics that deals with small objects and the quantization of various entities, including energy and angular momentum. Just as with classical physics, quantum physics has several subfields, such as mechanics and the study of electromagnetic forces. The correspondence principle states that in the classical limit (large, slow-moving objects), quantum mechanics becomes the same as classical physics. In this chapter, we begin the development of quantum mechanics and its description of the strange submicroscopic world. In later chapters, we will examine many areas, such as atomic and nuclear physics, in which quantum mechanics is crucial.