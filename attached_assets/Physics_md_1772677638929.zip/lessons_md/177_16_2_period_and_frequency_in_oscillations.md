# 16.2 Period and Frequency in Oscillations

[Original URL](https://openstax.org/books/college-physics-2e/pages/16-2-period-and-frequency-in-oscillations)

## 16.2 Period and Frequency in Oscillations

### Learning Objectives

By the end of this section, you will be able to:

*   Observe the vibrations of a guitar string.
*   Determine the frequency of oscillations.

![The given figure shows a closed zoom view of the strings of a guitar. There are two slanting white colored strings in the picture. In the nearer string, the gaps between the circular threads of the string are visible, whereas the second white string at the back looks like a white thin stick.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/5103cbfeaf72165c4854548eb09eeca009a9cf69)

Figure 16.8 The strings on this guitar vibrate at regular time intervals. (credit: JAR)

When you pluck a guitar string, the resulting sound has a steady tone and lasts a long time. Each successive vibration of the string takes the same time as the previous one. We define periodic motion to be a motion that repeats itself at regular time intervals, such as exhibited by the guitar string or by an object on a spring moving up and down. The time to complete one oscillation remains constant and is called the period TT. Its units are usually seconds, but may be any convenient unit of time. The word period refers to the time for some event whether repetitive or not; but we shall be primarily interested in periodic motion, which is by definition repetitive. A concept closely related to period is the frequency of an event. For example, if you get a paycheck twice a month, the frequency of payment is two per month and the period between checks is half a month. Frequency ff is defined to be the number of events per unit time. For periodic motion, frequency is the number of oscillations per unit time. The relationship between frequency and period is

f\=1T.f\=1T.

16.8

The SI unit for frequency is the _cycle per second_, which is defined to be a _hertz_ (Hz):

1 Hz \= 1 cycle s or 1 Hz \= 1 s 1 Hz \= 1 cycle s or 1 Hz \= 1 s

16.9

A cycle is one complete oscillation. Note that a vibration can be a single or multiple event, whereas oscillations are usually repetitive for a significant number of cycles.

#### Determine the Frequency of Two Oscillations: Medical Ultrasound and the Period of Middle C

We can use the formulas presented in this module to determine both the frequency based on known oscillations and the oscillation based on a known frequency. Let’s try one example of each. (a) A medical imaging device produces ultrasound by oscillating with a period of 0.400 µs. What is the frequency of this oscillation? (b) The frequency of middle C on a typical musical instrument is 264 Hz. What is the time for one complete oscillation?

#### Strategy

Both questions (a) and (b) can be answered using the relationship between period and frequency. In question (a), the period _TT_ is given and we are asked to find frequency ff. In question (b), the frequency ff is given and we are asked to find the period _TT_.

#### Solution a

1.  Substitute 0 . 400 μ s 0 . 400 μ s for _TT_ in f\=1Tf\=1T:
    
    f \= 1 T \= 1 0 . 400 × 10 − 6 s . f \= 1 T \= 1 0 . 400 × 10 − 6 s .
    
    16.10
    
    Solve to find
    
    f \= 2 . 50 × 10 6 Hz . f \= 2 . 50 × 10 6 Hz .
    
    16.11
    

#### Discussion a

The frequency of sound found in (a) is much higher than the highest frequency that humans can hear and, therefore, is called ultrasound. Appropriate oscillations at this frequency generate ultrasound used for noninvasive medical diagnoses, such as observations of a fetus in the womb.

#### Solution b

1.  Identify the known values:
    
    The time for one complete oscillation is the period _TT_:
    
    f \= 1 T . f \= 1 T .
    
    16.12
    
2.  Solve for _TT_:
    
    T \= 1 f . T \= 1 f .
    
    16.13
    
3.  Substitute the given value for the frequency into the resulting expression:
    
    T \= 1 f \= 1 264 Hz \= 1 264 cycles/s \= 3 . 79 × 10 − 3 s \= 3 . 79 ms . T \= 1 f \= 1 264 Hz \= 1 264 cycles/s \= 3 . 79 × 10 − 3 s \= 3 . 79 ms .
    
    16.14
    

#### Discussion b

The period found in (b) is the time per cycle, but this value is often quoted as simply the time in convenient units (ms or milliseconds in this case).

Identify an event in your life (such as receiving a paycheck) that occurs regularly. Identify both the period and frequency of this event.

#### Solution

I visit my parents for dinner every other Sunday. The frequency of my visits is 26 per calendar year. The period is two weeks.