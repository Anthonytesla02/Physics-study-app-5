# Introduction to Electric Charge and Electric Field

[Original URL](https://openstax.org/books/college-physics-2e/pages/18-introduction-to-electric-charge-and-electric-field)

![A child swoops down a plastic playground slide, his hair standing on end.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/0b01beb41039975be3d5e96ed92d0db8cf50923d)

Figure 18.1 Static electricity from this plastic slide causes the child’s hair to stand on end. The sliding motion stripped electrons away from the child’s body, leaving an excess of positive charges, which repel each other along each strand of hair. (credit: Ken Bosma/Wikimedia Commons)

## Chapter Outline

[18.1 Static Electricity and Charge: Conservation of Charge](18-1-static-electricity-and-charge-conservation-of-charge)

[18.2 Conductors and Insulators](18-2-conductors-and-insulators)

[18.3 Coulomb’s Law](18-3-coulombs-law)

[18.4 Electric Field: Concept of a Field Revisited](18-4-electric-field-concept-of-a-field-revisited)

[18.5 Electric Field Lines: Multiple Charges](18-5-electric-field-lines-multiple-charges)

[18.6 Electric Forces in Biology](18-6-electric-forces-in-biology)

[18.7 Conductors and Electric Fields in Static Equilibrium](18-7-conductors-and-electric-fields-in-static-equilibrium)

[18.8 Applications of Electrostatics](18-8-applications-of-electrostatics)

## Introduction to Electric Charge and Electric Field

The image of American politician and scientist Benjamin Franklin (1706–1790) flying a kite in a thunderstorm is familiar to many schoolchildren. (See [Figure 18.2](18-introduction-to-electric-charge-and-electric-field#import-auto-id1492127).) In this experiment, Franklin demonstrated a connection between lightning and static electricity. Sparks were drawn from a key hung on a kite string during an electrical storm. These sparks were like those produced by static electricity, such as the spark that jumps from your finger to a metal doorknob after you walk across a wool carpet. What Franklin demonstrated in his dangerous experiment was a connection between phenomena on two different scales: one the grand power of an electrical storm, the other an effect of more human proportions. Connections like this one reveal the underlying unity of the laws of nature, an aspect we humans find particularly appealing.

![Benjamin Franklin is shown flying a kite and lightning is observed. A metal key is attached to the string.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/893f58edff0e212ddd59a07d596bab8986883f32)

Figure 18.2 When Benjamin Franklin demonstrated that lightning was related to static electricity, he made a connection that is now part of the evidence that all directly experienced forces except the gravitational force are manifestations of the electromagnetic force.

Much has been written about Franklin. His experiments were only part of the life of a man who was a scientist, inventor, revolutionary, statesman, and writer. Franklin’s experiments were not performed in isolation, nor were they the only ones to reveal connections.

For example, the Italian scientist Luigi Galvani (1737–1798) performed a series of experiments in which static electricity was used to stimulate contractions of leg muscles of dead frogs, an effect already known in humans subjected to static discharges. But Galvani also found that if he joined two metal wires (say copper and zinc) end to end and touched the other ends to muscles, he produced the same effect in frogs as static discharge. Alessandro Volta (1745–1827), partly inspired by Galvani’s work, experimented with various combinations of metals and developed the battery.

During the same era, other scientists made progress in discovering fundamental connections. The periodic table was developed as the systematic properties of the elements were discovered. This influenced the development and refinement of the concept of atoms as the basis of matter. Such submicroscopic descriptions of matter also help explain a great deal more.

Atomic and molecular interactions, such as the forces of friction, cohesion, and adhesion, are now known to be manifestations of the electromagnetic force. Static electricity is just one aspect of the electromagnetic force, which also includes moving electricity and magnetism.

All the macroscopic forces that we experience directly, such as the sensations of touch and the tension in a rope, are due to the electromagnetic force, one of the four fundamental forces in nature. The gravitational force, another fundamental force, is actually sensed through the electromagnetic interaction of molecules, such as between those in our feet and those on the top of a bathroom scale. (The other two fundamental forces, the strong nuclear force and the weak nuclear force, cannot be sensed on the human scale.)

This chapter begins the study of electromagnetic phenomena at a fundamental level. The next several chapters will cover static electricity, moving electricity, and magnetism—collectively known as electromagnetism. In this chapter, we begin with the study of electric phenomena due to charges that are at least temporarily stationary, called electrostatics, or static electricity.

[Access multimedia content](http://openstax.org/books/college-physics-2e/pages/18-introduction-to-electric-charge-and-electric-field)