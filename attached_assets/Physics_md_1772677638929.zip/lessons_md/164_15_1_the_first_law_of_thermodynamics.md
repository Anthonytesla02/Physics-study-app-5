# 15.1 The First Law of Thermodynamics

[Original URL](https://openstax.org/books/college-physics-2e/pages/15-1-the-first-law-of-thermodynamics)

## 15.1 The First Law of Thermodynamics

### Learning Objectives

By the end of this section, you will be able to:

*   Define the first law of thermodynamics.
*   Describe how conservation of energy relates to the first law of thermodynamics.
*   Identify instances of the first law of thermodynamics working in everyday situations, including biological metabolism.
*   Calculate changes in the internal energy of a system, after accounting for heat transfer and work done.

![The photograph shows water boiling in a tea kettle kept on a stove. The water vapor is shown to emerge out of the nozzle of the kettle.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/0e851301cb72fc0ccb224acbe20ef71231acb270)

Figure 15.2 This boiling tea kettle represents energy in motion. The water in the kettle is turning to water vapor because heat is being transferred from the stove to the kettle. As the entire system gets hotter, work is done—from the evaporation of the water to the whistling of the kettle. (credit: Gina Hamilton)

If we are interested in how heat transfer is converted into doing work, then the conservation of energy principle is important. The first law of thermodynamics applies the conservation of energy principle to systems where heat transfer and doing work are the methods of transferring energy into and out of the system. The first law of thermodynamics states that the change in internal energy of a system equals the net heat transfer _into_ the system minus the net work done _by_ the system. In equation form, the first law of thermodynamics is

ΔEint\=Q−W.ΔEint\=Q−W.

15.1

Here ΔEintΔEint is the _change in internal energy_ EintEint of the system. QQ is the _net heat transferred into the system_—that is, QQ is the sum of all heat transfer into and out of the system. WW is the _net work done by the system_—that is, WW is the sum of all work done on or by the system. We use the following sign conventions: if QQ is positive, then there is a net heat transfer into the system; if WW is positive, then there is net work done by the system. So positive QQ adds energy to the system and positive WW takes energy from the system. Thus ΔEint\=Q−WΔEint\=Q−W. Note also that if more heat transfer into the system occurs than work done, the difference is stored as internal energy. Heat engines are a good example of this—heat transfer into them takes place so that they can do work. (See [Figure 15.3](15-1-the-first-law-of-thermodynamics#import-auto-id1169738092310).) We will now examine QQ, WW, and ΔEintΔEint further.

![The figure shows a schematic diagram of a system shown by an ellipse. Heat Q is shown to enter the system as shown by a bold arrow toward the ellipse. The work done is shown pointing away from the system. The internal energy of the system is marked as delta E sub int equals Q minus W. The second part of the figure shows two arrow diagrams for the heat change Q and work W. Q is shown as Q in minus Q out. W is shown as W out minus W in.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/b921fc06a454efde8c7d91ff3bf566587e69fd53)

Figure 15.3 The first law of thermodynamics is the conservation-of-energy principle stated for a system where heat and work are the methods of transferring energy for a system in thermal equilibrium. QQ represents the net heat transfer—it is the sum of all heat transfers into and out of the system. QQ is positive for net heat transfer _into_ the system. WW is the total work done on and by the system. WW is positive when more work is done _by_ the system than on it. The change in the internal energy of the system, ΔEintΔEint, is related to heat and work by the first law of thermodynamics, ΔEint\=Q−WΔEint\=Q−W.

The first law of thermodynamics is actually the law of conservation of energy stated in a form most useful in thermodynamics. The first law gives the relationship between heat transfer, work done, and the change in internal energy of a system.

### Heat _Q_ and Work _W_

Heat transfer (QQ) and doing work (WW) are the two everyday means of bringing energy into or taking energy out of a system. The processes are quite different. Heat transfer, a less organized process, is driven by temperature differences. Work, a quite organized process, involves a macroscopic force exerted through a distance. Nevertheless, heat and work can produce identical results.For example, both can cause a temperature increase. Heat transfer into a system, such as when the Sun warms the air in a bicycle tire, can increase its temperature, and so can work done on the system, as when the bicyclist pumps air into the tire. Once the temperature increase has occurred, it is impossible to tell whether it was caused by heat transfer or by doing work. This uncertainty is an important point. Heat transfer and work are both energy in transit—neither is stored as such in a system. However, both can change the internal energy EintEint of a system. Internal energy is a form of energy completely different from either heat or work.

### Internal Energy _E_int

We can think about the internal energy of a system in two different but consistent ways. The first is the atomic and molecular view, which examines the system on the atomic and molecular scale. The internal energy EintEint of a system is the sum of the kinetic and potential energies of its atoms and molecules. Recall that kinetic plus potential energy is called mechanical energy. Thus internal energy is the sum of atomic and molecular mechanical energy. Because it is impossible to keep track of all individual atoms and molecules, we must deal with averages and distributions. A second way to view the internal energy of a system is in terms of its macroscopic characteristics, which are very similar to atomic and molecular average values.

Macroscopically, we define the change in internal energy ΔEintΔEint to be that given by the first law of thermodynamics:

ΔEint\=Q−W.ΔEint\=Q−W.

15.2

Many detailed experiments have verified that ΔEint\=Q−WΔEint\=Q−W, where ΔEintΔEint is the change in total kinetic and potential energy of all atoms and molecules in a system. It has also been determined experimentally that the internal energy EintEint of a system depends only on the state of the system and _not how it reached that state_. More specifically, EintEint is found to be a function of a few macroscopic quantities (pressure, volume, and temperature, for example), independent of past history such as whether there has been heat transfer or work done. This independence means that if we know the state of a system, we can calculate changes in its internal energy EintEint from a few macroscopic variables.

In thermodynamics, we often use the macroscopic picture when making calculations of how a system behaves, while the atomic and molecular picture gives underlying explanations in terms of averages and distributions. We shall see this again in later sections of this chapter. For example, in the topic of entropy, calculations will be made using the atomic and molecular view.

To get a better idea of how to think about the internal energy of a system, let us examine a system going from State 1 to State 2. The system has internal energy Eint1Eint1 in State 1, and it has internal energy Eint2Eint2 in State 2, no matter how it got to either state. So the change in internal energy ΔEint\=Eint2−Eint1ΔEint\=Eint2−Eint1 is independent of what caused the change. In other words, ΔEintΔEint _is independent of path_. By path, we mean the method of getting from the starting point to the ending point. Why is this independence important? Note that ΔEint\=Q−WΔEint\=Q−W. Both QQ and WW _depend on path_, but ΔEintΔEint does not. This path independence means that internal energy EintEint is easier to consider than either heat transfer or work done.

#### Calculating Change in Internal Energy: The Same Change in EintEint is Produced by Two Different Processes

(a) Suppose there is heat transfer of 40.00 J to a system, while the system does 10.00 J of work. Later, there is heat transfer of 25.00 J out of the system while 4.00 J of work is done on the system. What is the net change in internal energy of the system?

(b) What is the change in internal energy of a system when a total of 150.00 J of heat transfer occurs out of (from) the system and 159.00 J of work is done on the system? (See [Figure 15.4](15-1-the-first-law-of-thermodynamics#import-auto-id1169738082268)).

#### Strategy

In part (a), we must first find the net heat transfer and net work done from the given information. Then the first law of thermodynamics (ΔEint\=Q−W)(ΔEint\=Q−W) can be used to find the change in internal energy. In part (b), the net heat transfer and work done are given, so the equation can be used directly.

#### Solution for (a)

The net heat transfer is the heat transfer into the system minus the heat transfer out of the system, or

Q\=40.00J−25.00 J\=15.00J.Q\=40.00J−25.00 J\=15.00J.

15.3

Similarly, the total work is the work done by the system minus the work done on the system, or

W\=10.00J−4.00J\=6.00 J.W\=10.00J−4.00J\=6.00 J.

15.4

Thus the change in internal energy is given by the first law of thermodynamics:

ΔEint\=Q−W\=15.00J−6.00J\=9.00 J.ΔEint\=Q−W\=15.00J−6.00J\=9.00 J.

15.5

We can also find the change in internal energy for each of the two steps. First, consider 40.00 J of heat transfer in and 10.00 J of work out, or

ΔEint1\=Q1−W1\=40.00J−10.00J\=30.00 J.ΔEint1\=Q1−W1\=40.00J−10.00J\=30.00 J.

15.6

Now consider 25.00 J of heat transfer out and 4.00 J of work in, or

ΔEint2\=Q2−W2\=\-25.00J−(−4.00J)\=–21.00 J.ΔEint2\=Q2−W2\=\-25.00J−(−4.00J)\=–21.00 J.

15.7

The total change is the sum of these two steps, or

ΔEint\=ΔEint1+ΔEint2\=30.00J+−21.00J\=9.00 J.ΔEint\=ΔEint1+ΔEint2\=30.00J+−21.00J\=9.00 J.

15.8

#### Discussion on (a)

No matter whether you look at the overall process or break it into steps, the change in internal energy is the same.

#### Solution for (b)

Here the net heat transfer and total work are given directly to be Q\=–150.00 JQ\=–150.00 J and W\=–159.00 JW\=–159.00 J, so that

ΔEint\=Q–W\=–150.00 J–(−159.00 J)\=9.00 J.ΔEint\=Q–W\=–150.00 J–(−159.00 J)\=9.00 J.

15.9

#### Discussion on (b)

A very different process in part (b) produces the same 9.00-J change in internal energy as in part (a). Note that the change in the system in both parts is related to ΔEintΔEint and not to the individual QQs or WWs involved. The system ends up in the _same_ state in both (a) and (b). Parts (a) and (b) present two different paths for the system to follow between the same starting and ending points, and the change in internal energy for each is the same—it is independent of path.

![The first part of the picture shows a system in the form of a circle for explanation purposes. The heat entering and work done are represented by bold arrows. A quantity of heat Q in equals forty joules, is shown to enter the system and Q out equals negative twenty five joules is shown to leave the system. The energy of the system in is marked as fifteen joules. At the right-hand side of the circle, a work W in equals negative four joules is shown to be applied on the system and a work W out equals ten joules is shown to leave the system. The energy of the system out is marked as six joules. The second part of the picture shows a system in the form of a circle for explanation purposes. The heat entering and work done are represented by bold arrows. A work of negative one hundred fifty nine is shown to enter the system. The energy in the system is shown as one hundred fifty nine joules. The out energy of the system is one hundred fifty joules. A heat Q out of negative one hundred fifty joules is shown to leave the system as an outward arrow.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/2f9edb0d623355dd964a523456c2a0e90880a238)

Figure 15.4 Two different processes produce the same change in a system. (a) A total of 15.00 J of heat transfer occurs into the system, while work takes out a total of 6.00 J. The change in internal energy is ΔEint\=Q−W\=9.00 JΔEint\=Q−W\=9.00 J. (b) Heat transfer removes 150.00 J from the system while work puts 159.00 J into it, producing an increase of 9.00 J in internal energy. If the system starts out in the same state in (a) and (b), it will end up in the same final state in either case—its final state is related to internal energy, not how that energy was acquired.

#### Human Metabolism and the First Law of Thermodynamics

Human metabolism is the conversion of food into heat transfer, work, and stored fat. Metabolism is an interesting example of the first law of thermodynamics in action. We now take another look at these topics via the first law of thermodynamics. Considering the body as the system of interest, we can use the first law to examine heat transfer, doing work, and internal energy in activities ranging from sleep to heavy exercise. What are some of the major characteristics of heat transfer, doing work, and energy in the body? For one, body temperature is normally kept constant by heat transfer to the surroundings. This means QQ is negative. Another fact is that the body usually does work on the outside world. This means WW is positive. In such situations, then, the body loses internal energy, since ΔEint\=Q−WΔEint\=Q−W is negative.

Now consider the effects of eating. Eating increases the internal energy of the body by adding chemical potential energy (this is an unromantic view of a good steak). The body _metabolizes_ all the food we consume. Basically, metabolism is an oxidation process in which the chemical potential energy of food is released. This implies that food input is in the form of work. Food energy is reported in a special unit, known as the Calorie. This energy is measured by burning food in a calorimeter, which is how the units are determined.

In chemistry and biochemistry, one calorie (spelled with a _lowercase_ c) is defined as the energy (or heat transfer) required to raise the temperature of one gram of pure water by one degree Celsius. Nutritionists and weight-watchers tend to use the _dietary_ calorie, which is frequently called a Calorie (spelled with a _capital_ C). One food Calorie is the energy needed to raise the temperature of one _kilogram_ of water by one degree Celsius. This means that one dietary Calorie is equal to one kilocalorie for the chemist, and one must be careful to avoid confusion between the two.

Again, consider the internal energy the body has lost. There are three places this internal energy can go—to heat transfer, to doing work, and to stored fat (a tiny fraction also goes to cell repair and growth). Heat transfer and doing work take internal energy out of the body, and food puts it back. If you eat just the right amount of food, then your average internal energy remains constant. Whatever you lose to heat transfer and doing work is replaced by food, so that, in the long run, ΔEint\=0ΔEint\=0. If you overeat repeatedly, then ΔEintΔEint is always positive, and your body stores this extra internal energy as fat. The reverse is true if you eat too little. If ΔEintΔEint is negative for a few days, then the body metabolizes its own fat to maintain body temperature and do work that takes energy from the body. This process is how dieting produces weight loss.

Life is not always this simple, as any dieter knows. The body stores fat or metabolizes it only if energy intake changes for a period of several days. Once you have been on a major diet, the next one is less successful because your body alters the way it responds to low energy intake. Your basal metabolic rate (BMR) is the rate at which food is converted into heat transfer and work done while the body is at complete rest. The body adjusts its basal metabolic rate to partially compensate for over-eating or under-eating. The body will decrease the metabolic rate rather than eliminate its own fat to replace lost food intake. You will chill more easily and feel less energetic as a result of the lower metabolic rate, and you will not lose weight as fast as before. Exercise helps to lose weight, because it produces both heat transfer from your body and work, and raises your metabolic rate even when you are at rest. Weight loss is also aided by the quite low efficiency of the body in converting internal energy to work, so that the loss of internal energy resulting from doing work is much greater than the work done.It should be noted, however, that living systems are not in thermalequilibrium.

The body provides us with an excellent indication that many thermodynamic processes are _irreversible_. An irreversible process can go in one direction but not the reverse, under a given set of conditions. For example, although body fat can be converted to do work and produce heat transfer, work done on the body and heat transfer into it cannot be converted to body fat. Otherwise, we could skip lunch by sunning ourselves or by walking down stairs. Another example of an irreversible thermodynamic process is photosynthesis. This process is the intake of one form of energy—light—by plants and its conversion to chemical potential energy. Both applications of the first law of thermodynamics are illustrated in [Figure 15.5](15-1-the-first-law-of-thermodynamics#import-auto-id1169737762762). One great advantage of conservation laws such as the first law of thermodynamics is that they accurately describe the beginning and ending points of complex processes, such as metabolism and photosynthesis, without regard to the complications in between. [Table 15.1](15-1-the-first-law-of-thermodynamics#import-auto-id1169738198965) presents a summary of terms relevant to the first law of thermodynamics.

![Part a of the figure is a pictorial representation of metabolism in a human body. The food is shown to enter the body as shown by a bold arrow toward the body. Work W and heat Q leave the body as shown by bold arrows pointing outward from the body. Delta E sub int is shown as the stored food energy. Part b of the figure shows the metabolism in plants .The heat from the sunlight is shown to fall on a plant represented as Q in. The heat given out by the plant is shown as Q out by an arrow pointing away from the plant.](/apps/image-cdn/v1/f=webp/apps/archive/20260105.231123/resources/d6614c97464f27aa4fe6c7b01ed6245c717d9b6e)

Figure 15.5 (a) The first law of thermodynamics applied to metabolism. Heat transferred out of the body (QQ) and work done by the body (WW) remove internal energy, while food intake replaces it. (Food intake may be considered as work done on the body.) (b) Plants convert part of the radiant heat transfer in sunlight to stored chemical energy, a process called photosynthesis.

Term

Definition

Eint Eint

Internal energy—the sum of the kinetic and potential energies of a system’s atoms and molecules. Can be divided into many subcategories, such as thermal and chemical energy. Depends only on the state of a system (such as its PP, VV, and TT), not on how the energy entered the system. Change in internal energy is path independent.

Q Q

Heat—energy transferred because of a temperature difference. Characterized by random molecular motion. Highly dependent on path. QQ entering a system is positive.

W W

Work—energy transferred by a force moving through a distance. An organized, orderly process. Path dependent. WW done by a system (either against an external force or to increase the volume of the system) is positive.

Table 15.1 Summary of Terms for the First Law of Thermodynamics, _ΔEint\=Q−W_