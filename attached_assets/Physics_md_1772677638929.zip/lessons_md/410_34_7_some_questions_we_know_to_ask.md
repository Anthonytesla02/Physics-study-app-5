# 34.7 Some Questions We Know to Ask

[Original URL](https://openstax.org/books/college-physics-2e/pages/34-7-some-questions-we-know-to-ask)

## 34.7 Some Questions We Know to Ask

### Learning Objectives

By the end of this section, you will be able to:

*   Identify sample questions to be asked on the largest scales.
*   Identify sample questions to be asked on the intermediate scale.
*   Identify sample questions to be asked on the smallest scales.

Throughout the text we have noted how essential it is to be curious and to ask questions in order to first understand what is known, and then to go a little farther. Some questions may go unanswered for centuries; others may not have answers, but some bear delicious fruit. Part of discovery is knowing which questions to ask. You have to know something before you can even phrase a decent question. As you may have noticed, the mere act of asking a question can give you the answer. The following questions are a sample of those physicists now know to ask and are representative of the forefronts of physics. Although these questions are important, they will be replaced by others if answers are found to them. The fun continues.

### On the Largest Scale

1.  _Is the universe open or closed_? Theorists would like it to be just barely closed and evidence is building toward that conclusion. Recent measurements in the expansion rate of the universe and in CMBR support a flat universe. There is a connection to small-scale physics in the type and number of particles that may contribute to closing the universe.
2.  _What is dark matter_? It is definitely there, but we really do not know what it is. Conventional possibilities are being ruled out, but one of them still may explain it. The answer could reveal whole new realms of physics and the disturbing possibility that most of what is out there is unknown to us, a completely different form of matter.
3.  _How do galaxies form_? They exist since very early in the evolution of the universe and it remains difficult to understand how they evolved so quickly. The recent finer measurements of fluctuations in the CMBR may yet allow us to explain galaxy formation.
4.  _What is the nature of various-mass black holes_? Only recently have we become confident that many black hole candidates cannot be explained by other, less exotic possibilities. But we still do not know much about how they form, what their role in the history of galactic evolution has been, and the nature of space in their vicinity. However, so many black holes are now known that correlations between black hole mass and galactic nuclei characteristics are being studied.
5.  _What is the mechanism for the energy output of quasars_? These distant and extraordinarily energetic objects now seem to be early stages of galactic evolution with a supermassive black-hole-devouring material. Connections are now being made with galaxies having energetic cores, and there is evidence consistent with less consuming, supermassive black holes at the center of older galaxies. New instruments are allowing us to see deeper into our own galaxy for evidence of our own massive black hole.
6.  _Where do the γγ bursts come from_? We see bursts of γγ rays coming from all directions in space, indicating the sources are very distant objects rather than something associated with our own galaxy. Some γγ bursts finally are being correlated with known sources so that the possibility they may originate in binary neutron star interactions or black holes eating a companion neutron star can be explored.

### On the Intermediate Scale

1.  _How do phase transitions take place on the microscopic scale_? We know a lot about phase transitions, such as water freezing, but the details of how they occur molecule by molecule are not well understood. Similar questions about specific heat a century ago led to early quantum mechanics. It is also an example of a complex adaptive system that may yield insights into other self-organizing systems.
2.  _Is there a way to deal with nonlinear phenomena that reveals underlying connections_? Nonlinear phenomena lack a direct or linear proportionality that makes analysis and understanding a little easier. There are implications for nonlinear optics and broader topics such as chaos.
3.  _How do high- TcTc superconductors become resistanceless at such high temperatures_? Understanding how they work may help make them more practical or may result in surprises as unexpected as the discovery of superconductivity itself.
4.  _There are magnetic effects in materials we do not understand—how do they work_? Although beyond the scope of this text, there is a great deal to learn in condensed matter physics (the physics of solids and liquids). We may find surprises analogous to lasing, the quantum Hall effect, and the quantization of magnetic flux. Complexity may play a role here, too.

### On the Smallest Scale

1.  _Are quarks and leptons fundamental, or do they have a substructure_? The higher energy accelerators that are just completed or being constructed may supply some answers, but there will also be input from cosmology and other systematics.
2.  _Why do leptons have integral charge while quarks have fractional charge_? If both are fundamental and analogous as thought, this question deserves an answer. It is obviously related to the previous question.
3.  _Why are there three families of quarks and leptons_? First, does this imply some relationship? Second, why three and only three families?
4.  _Are all forces truly equal (unified) under certain circumstances_? They don’t have to be equal just because we want them to be. The answer may have to be indirectly obtained because of the extreme energy at which we think they are unified.
5.  _Are there other fundamental forces_? There was a flurry of activity with claims of a fifth and even a sixth force a few years ago. Interest has subsided, since those forces have not been detected consistently. Moreover, the proposed forces have strengths similar to gravity, making them extraordinarily difficult to detect in the presence of stronger forces. But the question remains; and if there are no other forces, we need to ask why only four and why these four.
6.  _Is the proton stable_? We have discussed this in some detail, but the question is related to fundamental aspects of the unification of forces. We may never know from experiment that the proton is stable, only that it is very long lived.
7.  _Are there magnetic monopoles_? Many particle theories call for very massive individual north- and south-pole particles—magnetic monopoles. If they exist, why are they so different in mass and elusiveness from electric charges, and if they do not exist, why not?
8.  _Do neutrinos have mass_? Definitive evidence has emerged for neutrinos having mass. The implications are significant, as discussed in this chapter. There are effects on the closure of the universe and on the patterns in particle physics.
9.  _What are the systematic characteristics of high- ZZ nuclei_? All elements with Z\=118Z\=118 or less (with the exception of 115 and 117) have now been discovered. It has long been conjectured that there may be an island of relative stability near Z\=114Z\=114, and the study of the most recently discovered nuclei will contribute to our understanding of nuclear forces.

These lists of questions are not meant to be complete or consistently important—you can no doubt add to it yourself. There are also important questions in topics not broached in this text, such as certain particle symmetries, that are of current interest to physicists. Hopefully, the point is clear that no matter how much we learn, there always seems to be more to know. Although we are fortunate to have the hard-won wisdom of those who preceded us, we can look forward to new enlightenment, undoubtedly sprinkled with surprise.